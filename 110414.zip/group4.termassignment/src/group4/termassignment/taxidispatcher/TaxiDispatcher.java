package group4.termassignment.taxidispatcher;

import no.ntnu.item.arctis.runtime.Block;

public class TaxiDispatcher extends Block {

	public void proceedData(String data, String topic) {
	}

	public void x() {
	}

}
