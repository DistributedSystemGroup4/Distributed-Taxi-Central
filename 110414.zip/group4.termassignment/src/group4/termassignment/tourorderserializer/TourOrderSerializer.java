package group4.termassignment.tourorderserializer;

import no.ntnu.item.arctis.runtime.Block;

public class TourOrderSerializer extends Block {

}
