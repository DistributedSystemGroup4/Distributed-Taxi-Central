package group4.termassignment.utilserializer;

import no.ntnu.item.arctis.runtime.Block;

public class UtilSerializer extends Block {
}