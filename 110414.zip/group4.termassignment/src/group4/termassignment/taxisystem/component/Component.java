package group4.termassignment.taxisystem.component;

import no.ntnu.item.arctis.runtime.Block;

public class Component extends Block {

}
