package group4.termassignment.taxisystem;

import no.ntnu.item.arctis.runtime.Block;

public class TaxiSystem extends Block {

}
