package group4.termassignment.taxisimulator;

import no.ntnu.item.arctis.runtime.Block;

public class TaxiSimulator extends Block {

}
