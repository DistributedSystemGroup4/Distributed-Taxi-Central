package group4.termassignment.taxicentral;

import no.ntnu.item.arctis.runtime.Block;

public class TaxiCentral extends Block {

}
